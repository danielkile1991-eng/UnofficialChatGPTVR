# Unofficial ChatGPT VR (Meta Quest, native Android, no Unity)

Independent, free, open-source ChatGPT client for Meta Quest. NOT made, endorsed or sponsored by OpenAI.
It runs as a 2D panel window in Horizon OS (Companion Mode), with typed Chat Mode and hands-free Voice Mode.
No Unity is used or needed. If a future feature needs it (for example a 3D room), that will be flagged first.

STATUS: written but not yet compiled or run on a headset. Expect small build fixes on first compile.

## Scope
- ChatGPT only. Claude and Grok were removed completely.
- Sign in with ChatGPT (official OAuth + PKCE, open-source flow). No passwords, no API keys, ever typed or pasted.
- Uses the user's own ChatGPT plan allowance. No developer server, no subscription, no ads. MIT license.

## Interface (original components, adapted for controllers)
Layout and palette follow the reference screenshots in spirit only (black canvas, soft gray rounded surfaces, blue accent).
Nothing is a screenshot, and no OpenAI logo or artwork is used; all icons are drawn in code.
- Chat screen: menu + title + new-chat top bar, right-aligned user bubbles, plain assistant text with Copy,
  suggestion rows on an empty chat, rounded input bar (+ quick actions, text field, dictation mic, Voice Mode / Send button),
  jump-to-latest button.
- Slide-out drawer: new chat, settings, searchable chat history with delete, avatar.
- Voice Mode: full-screen animated orb (listening / thinking / speaking), Pause and End, tap the orb to interrupt.
- Settings: account, sign out, custom instructions, model picker, text size, read-aloud, Companion Mode help,
  usage, diagnostics, privacy, about, delete all chats.
- Sign-in screen: single Continue button that opens OpenAI's own page in Quest Browser.

## Controller comfort
Every control is at least 64dp (bigger on key actions), hover highlight and press ripple for the pointer, no swipe-only or
long-press-only actions, text scales 90 to 160%, bottom sheets instead of tiny dialogs, large Copy / Delete targets.

## Companion Mode (what the platform allows)
The app is a Horizon OS 2D panel (`com.oculus.intent.category.2D`). The system lets you move, resize, minimize and reopen it,
and (v74+) keep windows open next to immersive apps. A normal app cannot draw its own overlay over another VR app, and this one
doesn't try. Whether it stays visible next to a given game depends on that game and your OS version. Test your favorites.

## Build the APK
A) No PC: push this folder to a public GitHub repo; the workflow in .github/workflows builds a debug APK (Artifacts).
B) Android Studio: open folder, sync (AGP 8.7.3, Kotlin 2.0.21, Gradle 8.9), Build > Build APK(s).

## Install
Developer Mode on (Meta Horizon phone app), then `adb install -r app-debug.apk` or SideQuest.
Launch from Library > Unknown Sources > Unofficial ChatGPT VR.

## First-run checklist
1. Settings > Diagnostics: speech recognition / text-to-speech available?
2. Continue with ChatGPT. Quest Browser should return to 127.0.0.1 and show the chat. If the return trip fails, report it.
3. Type a message: streamed reply = plan auth works.
4. Open another VR app, then this window. Try move, resize, minimize, reopen.
5. Voice Mode only starts if speech recognition exists; otherwise it says so and Chat Mode keeps working.

## Rules you must follow to ship
Keep the source public (OpenAI's plan-usage sign-in is for open-source apps). Use OpenAI's approved "Continue with ChatGPT"
button assets if you publish (this prototype uses plain text). Keep the "unofficial" labels. Sideload only; Meta Store needs more work.

## Unverified
Sign-in return trip on Quest Browser; refresh-token request shape; `instructions` accepted on plan-usage requests;
Quest SpeechRecognizer / TextToSpeech availability; `moveTaskToBack` minimizing; default window size.
