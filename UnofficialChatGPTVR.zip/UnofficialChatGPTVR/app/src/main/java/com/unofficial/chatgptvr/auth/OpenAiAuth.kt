package com.unofficial.chatgptvr.auth

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.util.Base64
import com.unofficial.chatgptvr.util.Http
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader
import java.math.BigInteger
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.net.SocketTimeoutException
import java.net.URLDecoder
import java.security.KeyFactory
import java.security.MessageDigest
import java.security.SecureRandom
import java.security.Signature
import java.security.spec.RSAPublicKeySpec
import java.util.UUID

class Credentials(
    val clientId: String, val idToken: String, val accessToken: String, val refreshToken: String,
    val expiresAtMs: Long, val scopes: List<String>, val email: String?, val subject: String
) {
    fun toJson(): String = JSONObject()
        .put("client_id", clientId).put("id_token", idToken).put("access_token", accessToken)
        .put("refresh_token", refreshToken).put("expires_at", expiresAtMs)
        .put("scopes", JSONArray(scopes)).put("email", email ?: "").put("sub", subject).toString()

    companion object {
        fun fromJson(s: String): Credentials {
            val j = JSONObject(s)
            val sc = j.getJSONArray("scopes")
            return Credentials(
                j.getString("client_id"), j.getString("id_token"), j.getString("access_token"),
                j.getString("refresh_token"), j.getLong("expires_at"),
                (0 until sc.length()).map { sc.getString(it) }, j.optString("email").ifEmpty { null }, j.getString("sub")
            )
        }
    }
}

class PlanUseNotEnabled : IOException("ChatGPT plan use was not authorized. Sign in again and approve the ChatGPT plan permission.")

/**
 * "Sign in with ChatGPT" (OAuth 2.0 + OpenID Connect + PKCE) using OpenAI's open-source client flow.
 * No password, API key or secret is ever handled by this app: the user signs in inside Quest Browser and
 * OpenAI redirects back to a loopback listener on 127.0.0.1 with a one-time code.
 */
class OpenAiAuth(private val store: SecretStore) {
    private val rnd = SecureRandom()

    fun credentials(): Credentials? = store.get(K_CRED)?.let { runCatching { Credentials.fromJson(it) }.getOrNull() }
    fun isSignedIn() = credentials() != null
    fun signOutLocal() { store.remove(K_CRED) } // keeps the registered client id so re-sign-in is quicker

    private fun hostId(): String = store.get(K_HOST) ?: ("urn:uuid:" + UUID.randomUUID()).also { store.put(K_HOST, it) }
    private fun rand(n: Int): String { val b = ByteArray(n); rnd.nextBytes(b); return b64(b) }
    private fun b64(b: ByteArray) = Base64.encodeToString(b, Base64.URL_SAFE or Base64.NO_PADDING or Base64.NO_WRAP)
    private fun unb64(s: String) = Base64.decode(s, Base64.URL_SAFE or Base64.NO_PADDING or Base64.NO_WRAP)

    fun signIn(activity: Activity, onStatus: (String) -> Unit, onDone: (Result<Credentials>) -> Unit) {
        Thread {
            var server: ServerSocket? = null
            val result = runCatching {
                val state = rand(24); val nonce = rand(24); val verifier = rand(48)
                val challenge = b64(MessageDigest.getInstance("SHA-256").digest(verifier.toByteArray(Charsets.US_ASCII)))
                val loop = InetAddress.getByName("127.0.0.1")
                server = try { ServerSocket(1455, 4, loop) } catch (e: IOException) { ServerSocket(0, 4, loop) }
                server!!.soTimeout = 5 * 60_000
                val redirect = "http://127.0.0.1:${server!!.localPort}/auth/callback"
                val saved = store.get(K_CLIENT)

                val q = linkedMapOf(
                    "response_type" to "code", "client_id" to (saved ?: "dynamic_agent_client"),
                    "redirect_uri" to redirect, "scope" to SCOPES, "resource" to RESOURCE,
                    "state" to state, "nonce" to nonce, "code_challenge_method" to "S256",
                    "code_challenge" to challenge, "ext_agent_host_id" to hostId()
                )
                if (saved == null) q["agent_name_hint"] = AGENT_NAME
                val url = AUTH + "?" + q.entries.joinToString("&") { Http.enc(it.key) + "=" + Http.enc(it.value) }

                onStatus("Opening Quest Browser to sign in with ChatGPT...")
                activity.runOnUiThread {
                    activity.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }

                val cb = waitForCallback(server!!)
                if (cb["state"] != state) throw IOException("Sign-in response did not match this request (state mismatch).")
                cb["error"]?.let { throw IOException(if (it == "access_denied") "Sign-in was cancelled or denied." else "Sign-in error: $it") }
                val code = cb["code"] ?: throw IOException("Sign-in returned no authorization code.")
                val clientId = saved ?: cb["client_id"] ?: throw IOException("Registration incomplete: no client id was issued.")
                if (saved != null && cb["client_id"] != null && cb["client_id"] != saved) throw IOException("Unexpected client id in callback.")

                onStatus("Finishing sign-in...")
                val r = Http.postForm(TOKEN, mapOf(
                    "grant_type" to "authorization_code", "client_id" to clientId, "code" to code,
                    "code_verifier" to verifier, "redirect_uri" to redirect, "resource" to RESOURCE
                ))
                if (!r.ok) throw IOException("Token exchange failed (HTTP ${r.code}): ${errMsg(r.body)}")
                val t = JSONObject(r.body)
                val idToken = t.getString("id_token")
                val claims = verifyIdToken(idToken, clientId, nonce)
                val scopes = (t.optString("scope").ifEmpty { cb["scope"] ?: "" }).split(" ", "+").filter { it.isNotEmpty() }
                if ("chatgpt.tokens.use.direct" !in scopes) throw PlanUseNotEnabled()

                store.put(K_CLIENT, clientId)
                val cred = Credentials(
                    clientId, idToken, t.getString("access_token"), t.getString("refresh_token"),
                    System.currentTimeMillis() + t.optLong("expires_in", 3600) * 1000, scopes,
                    claims.optString("email").ifEmpty { null }, claims.getString("sub")
                )
                store.put(K_CRED, cred.toJson())
                cred
            }
            runCatching { server?.close() }
            onDone(result)
        }.start()
    }

    private fun waitForCallback(server: ServerSocket): Map<String, String> {
        repeat(6) {
            val sock: Socket = try { server.accept() } catch (e: SocketTimeoutException) { throw IOException("Sign-in timed out.") }
            try {
                sock.soTimeout = 8000
                val line = BufferedReader(InputStreamReader(sock.getInputStream())).readLine() ?: return@repeat
                val path = line.split(" ").getOrNull(1) ?: return@repeat
                if (!path.startsWith("/auth/callback")) { reply(sock, "Not found", 404); return@repeat }
                val params = path.substringAfter('?', "").split("&").filter { it.contains('=') }.associate {
                    URLDecoder.decode(it.substringBefore('='), "UTF-8") to URLDecoder.decode(it.substringAfter('='), "UTF-8")
                }
                reply(sock, "Signed in. You can close this tab and return to Unofficial ChatGPT VR.", 200)
                return params
            } catch (e: IOException) { /* speculative or broken connection: keep waiting */ } finally { runCatching { sock.close() } }
        }
        throw IOException("No valid sign-in callback received.")
    }

    private fun reply(s: Socket, text: String, code: Int) {
        val body = "<html><body style='font-family:sans-serif;padding:2em'><h2>$text</h2></body></html>"
        val out = "HTTP/1.1 $code OK\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: ${body.toByteArray().size}\r\nConnection: close\r\n\r\n$body"
        s.getOutputStream().apply { write(out.toByteArray()); flush() }
    }

    /** Verifies signature (RS256 against OpenAI's JWKS), issuer, audience, expiry and nonce. */
    private fun verifyIdToken(jwt: String, clientId: String, nonce: String): JSONObject {
        val parts = jwt.split(".")
        if (parts.size != 3) throw IOException("Malformed ID token.")
        val header = JSONObject(String(unb64(parts[0])))
        val claims = JSONObject(String(unb64(parts[1])))
        if (header.optString("alg") != "RS256") throw IOException("Unsupported ID token algorithm.")

        val disc = Http.get(DISCOVERY)
        if (!disc.ok) throw IOException("Could not load OpenAI discovery document.")
        val d = JSONObject(disc.body)
        val jwks = Http.get(d.getString("jwks_uri"))
        if (!jwks.ok) throw IOException("Could not load OpenAI signing keys.")
        val keys = JSONObject(jwks.body).getJSONArray("keys")
        var jwk: JSONObject? = null
        for (i in 0 until keys.length()) if (keys.getJSONObject(i).optString("kid") == header.optString("kid")) jwk = keys.getJSONObject(i)
        if (jwk == null) throw IOException("ID token signing key not found.")

        val pub = KeyFactory.getInstance("RSA").generatePublic(
            RSAPublicKeySpec(BigInteger(1, unb64(jwk.getString("n"))), BigInteger(1, unb64(jwk.getString("e"))))
        )
        val sig = Signature.getInstance("SHA256withRSA").apply { initVerify(pub); update((parts[0] + "." + parts[1]).toByteArray()) }
        if (!sig.verify(unb64(parts[2]))) throw IOException("ID token signature check failed.")

        if (claims.optString("iss") != d.getString("issuer")) throw IOException("ID token issuer mismatch.")
        val aud = claims.opt("aud")
        val audOk = if (aud is JSONArray) (0 until aud.length()).any { aud.getString(it) == clientId } else aud == clientId
        if (!audOk) throw IOException("ID token audience mismatch.")
        if (claims.optLong("exp") * 1000 < System.currentTimeMillis()) throw IOException("ID token expired.")
        if (claims.optString("nonce") != nonce) throw IOException("ID token nonce mismatch.")
        return claims
    }

    /** Returns a fresh access token, refreshing (and rotating the refresh token) when it is about to expire. */
    @Synchronized
    fun accessToken(): String {
        val c = credentials() ?: throw IOException("Not signed in.")
        if (c.expiresAtMs - System.currentTimeMillis() > 60_000) return c.accessToken
        val r = Http.postForm(TOKEN, mapOf("grant_type" to "refresh_token", "client_id" to c.clientId, "refresh_token" to c.refreshToken))
        if (!r.ok) {
            if (r.code == 400 || r.code == 401) { signOutLocal(); throw IOException("Your ChatGPT session expired. Please sign in again.") }
            throw IOException("Could not refresh session (HTTP ${r.code}).")
        }
        val t = JSONObject(r.body)
        val scopes = t.optString("scope").let { if (it.isEmpty()) c.scopes else it.split(" ").filter { s -> s.isNotEmpty() } }
        val n = Credentials(
            c.clientId, t.optString("id_token").ifEmpty { c.idToken }, t.getString("access_token"),
            t.optString("refresh_token").ifEmpty { c.refreshToken },
            System.currentTimeMillis() + t.optLong("expires_in", 3600) * 1000, scopes, c.email, c.subject
        )
        store.put(K_CRED, n.toJson())
        return n.accessToken
    }

    private fun errMsg(body: String): String = try {
        val j = JSONObject(body); j.optString("error_description").ifEmpty { j.optString("error") }.ifEmpty { body.take(160) }
    } catch (e: Exception) { body.take(160) }

    companion object {
        const val AUTH = "https://auth.openai.com/api/accounts/authorize"
        const val TOKEN = "https://auth.openai.com/api/accounts/oauth/token"
        const val DISCOVERY = "https://auth.openai.com/.well-known/openid-configuration"
        const val RESOURCE = "https://api.openai.com/v1"
        const val SCOPES = "openid profile email offline_access resource.invoke chatgpt.tokens.use.direct"
        const val AGENT_NAME = "Unofficial ChatGPT VR"
        private const val K_CRED = "openai_cred"
        private const val K_CLIENT = "openai_client_id"
        private const val K_HOST = "openai_host_id"
    }
}
