package com.unofficial.chatgptvr

import com.unofficial.chatgptvr.ai.Msg
import com.unofficial.chatgptvr.auth.SecretStore
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

class Conversation(val id: String = UUID.randomUUID().toString(), var title: String = "New chat",
                   val messages: MutableList<Msg> = mutableListOf(), var updated: Long = System.currentTimeMillis())

/** Chats live only on the headset, encrypted with the Android Keystore key (same store as the sign-in tokens). */
class ChatStore(private val secrets: SecretStore) {
    fun load(): MutableList<Conversation> {
        val raw = secrets.get(KEY) ?: return mutableListOf()
        return try {
            val a = JSONArray(raw); val out = mutableListOf<Conversation>()
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i); val ms = o.getJSONArray("m")
                out.add(Conversation(o.getString("id"), o.getString("t"),
                    (0 until ms.length()).map { Msg(ms.getJSONObject(it).getString("r"), ms.getJSONObject(it).getString("x")) }.toMutableList(),
                    o.optLong("u")))
            }
            out
        } catch (e: Exception) { mutableListOf() }
    }

    fun save(list: List<Conversation>) {
        val a = JSONArray()
        list.filter { it.messages.isNotEmpty() }.sortedByDescending { it.updated }.take(60).forEach { c ->
            a.put(JSONObject().put("id", c.id).put("t", c.title).put("u", c.updated)
                .put("m", JSONArray().also { ms -> c.messages.forEach { ms.put(JSONObject().put("r", it.role).put("x", it.text)) } }))
        }
        secrets.put(KEY, a.toString())
    }

    private companion object { const val KEY = "chats_v1" }
}
