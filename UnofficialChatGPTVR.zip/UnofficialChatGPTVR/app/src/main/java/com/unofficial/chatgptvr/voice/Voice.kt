package com.unofficial.chatgptvr.voice

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/**
 * Voice uses Android's own SpeechRecognizer and TextToSpeech. Whether a Quest headset ships working engines is
 * unverified, so every capability is probed at runtime and reported honestly; nothing is simulated.
 */
class Voice(
    private val activity: Activity,
    private val onHeard: (String) -> Unit,
    private val onStatus: (String) -> Unit,
    private val onFail: (Int) -> Unit = {}
) {
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    var ttsReady = false; private set
    var listening = false; private set

    val sttAvailable: Boolean get() = SpeechRecognizer.isRecognitionAvailable(activity)
    val hasMicPermission: Boolean get() = activity.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    fun requestMic() { activity.requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQ_MIC) }

    fun initTts() {
        if (tts != null) return
        tts = TextToSpeech(activity) { status ->
            ttsReady = status == TextToSpeech.SUCCESS
            if (ttsReady) tts?.language = Locale.getDefault()
            activity.runOnUiThread { if (!ttsReady) onStatus("Spoken replies unavailable: no text-to-speech engine on this headset.") }
        }
    }

    /** Starts one listening turn. Returns false (with a status message) if it cannot. */
    fun listen(): Boolean {
        if (!sttAvailable) { onStatus("Speech recognition is not available on this headset. Use the system keyboard's mic button or type instead."); return false }
        if (!hasMicPermission) { requestMic(); onStatus("Allow microphone access, then tap Mic again."); return false }
        val r = recognizer ?: SpeechRecognizer.createSpeechRecognizer(activity).also { recognizer = it }
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) { listening = true; onStatus("Listening...") }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() { listening = false }
            override fun onError(code: Int) { listening = false; onFail(code) }
            override fun onResults(res: Bundle?) {
                listening = false
                val t = res?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (t.isNullOrBlank()) onStatus("Nothing was heard.") else onHeard(t)
            }
            override fun onPartialResults(p: Bundle?) {}
            override fun onEvent(t: Int, p: Bundle?) {}
        })
        r.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false))
        return true
    }

    fun stopListening() { recognizer?.stopListening(); listening = false }

    fun speak(text: String, onDone: () -> Unit) {
        val t = tts
        if (t == null || !ttsReady) { activity.runOnUiThread(onDone); return }
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { activity.runOnUiThread(onDone) }
            @Deprecated("Deprecated in Java") override fun onError(id: String?) { activity.runOnUiThread(onDone) }
        })
        t.speak(text.take(3500), TextToSpeech.QUEUE_FLUSH, null, "aiu")
    }

    fun stopSpeaking() { tts?.stop() }

    fun shutdown() { recognizer?.destroy(); recognizer = null; tts?.shutdown(); tts = null }

    companion object { const val REQ_MIC = 42 }
}
