package com.unofficial.chatgptvr.util

import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

object Http {
    data class Resp(val code: Int, val body: String) { val ok get() = code in 200..299 }

    fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")

    private fun open(url: String, method: String, bearer: String?, timeoutMs: Int): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.connectTimeout = 20_000
        c.readTimeout = timeoutMs
        c.setRequestProperty("Accept", "application/json")
        if (bearer != null) c.setRequestProperty("Authorization", "Bearer $bearer")
        return c
    }

    private fun read(c: HttpURLConnection): Resp {
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else (c.errorStream ?: return Resp(code, ""))
        return Resp(code, stream.bufferedReader().use { it.readText() })
    }

    fun get(url: String, bearer: String? = null): Resp {
        val c = open(url, "GET", bearer, 30_000)
        try { return read(c) } catch (e: IOException) { throw IOException("Network error: ${e.message}", e) } finally { c.disconnect() }
    }

    fun postForm(url: String, fields: Map<String, String>): Resp {
        val c = open(url, "POST", null, 30_000)
        c.doOutput = true
        c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
        try {
            c.outputStream.use { it.write(fields.entries.joinToString("&") { e -> enc(e.key) + "=" + enc(e.value) }.toByteArray()) }
            return read(c)
        } catch (e: IOException) { throw IOException("Network error: ${e.message}", e) } finally { c.disconnect() }
    }

    /** Opens a JSON POST and returns the live connection so the caller can stream the body. Caller must disconnect. */
    fun openJsonPost(url: String, bearer: String, json: String, accept: String): HttpURLConnection {
        val c = open(url, "POST", bearer, 300_000)
        c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json")
        c.setRequestProperty("Accept", accept)
        c.outputStream.use { it.write(json.toByteArray()) }
        return c
    }
}
