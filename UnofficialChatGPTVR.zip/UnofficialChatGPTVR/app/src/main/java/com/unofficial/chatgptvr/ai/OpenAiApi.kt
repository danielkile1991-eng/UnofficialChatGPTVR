package com.unofficial.chatgptvr.ai

import com.unofficial.chatgptvr.auth.OpenAiAuth
import com.unofficial.chatgptvr.util.Http
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException

data class Msg(val role: String, val text: String)
data class ModelInfo(val slug: String, val name: String)
class ApiException(message: String) : IOException(message)

/** Responses API with the user's ChatGPT-plan OAuth token. store=false and stream=true are required by this flow. */
class OpenAiApi(private val auth: OpenAiAuth) {

    fun listModels(): List<ModelInfo> {
        val r = Http.get(OpenAiAuth.RESOURCE + "/models", auth.accessToken())
        if (!r.ok) throw ApiException("Could not load models (HTTP ${r.code}): ${message(r.body)}")
        val arr = JSONObject(r.body).optJSONArray("models") ?: JSONArray()
        val out = ArrayList<ModelInfo>()
        for (i in 0 until arr.length()) {
            val m = arr.getJSONObject(i)
            if (m.optString("visibility") == "list") out.add(ModelInfo(m.getString("slug"), m.optString("display_name").ifEmpty { m.getString("slug") }))
        }
        return out
    }

    /** Streams a reply, calling onDelta for each text chunk. Returns the full text only after response.completed. */
    fun stream(model: String, history: List<Msg>, custom: String?, onDelta: (String) -> Unit): String {
        val input = JSONArray().also { a -> history.forEach { a.put(JSONObject().put("role", it.role).put("content", it.text)) } }
        val body = JSONObject()
            .put("model", model).put("input", input).put("store", false).put("stream", true)
            .put("instructions", "You are an AI assistant used through an unofficial VR headset app. Replies are read in a floating panel or spoken aloud, so keep them concise unless asked for more." + (if (custom.isNullOrBlank()) "" else "\n\nUser's custom instructions:\n$custom"))
            .toString()
        val c = Http.openJsonPost(OpenAiAuth.RESOURCE + "/responses", auth.accessToken(), body, "text/event-stream")
        try {
            val code = c.responseCode
            if (code !in 200..299) throw ApiException("HTTP $code: " + message(c.errorStream?.bufferedReader()?.readText() ?: ""))
            val full = StringBuilder()
            var completed = false
            c.inputStream.bufferedReader().useLines { lines ->
                for (line in lines) {
                    if (!line.startsWith("data:")) continue
                    val payload = line.substring(5).trim()
                    if (payload.isEmpty() || payload == "[DONE]") continue
                    val j = JSONObject(payload)
                    when (j.optString("type")) {
                        "response.output_text.delta" -> { val d = j.optString("delta"); full.append(d); onDelta(d) }
                        "response.completed" -> completed = true
                        "response.incomplete" -> throw ApiException("The response was cut off (incomplete).")
                        "response.failed" -> throw ApiException(friendly(j.optJSONObject("response")?.optJSONObject("error")))
                        "error" -> throw ApiException(friendly(j))
                    }
                }
            }
            if (!completed) throw ApiException("The connection ended before the reply finished.")
            return full.toString()
        } finally { c.disconnect() }
    }

    private fun friendly(e: JSONObject?): String {
        val code = e?.optString("code").orEmpty()
        return when (code) {
            "subscription_sharing_usage_limit_exceeded" -> "Your ChatGPT plan usage limit for this app is reached. Raise it in ChatGPT settings, or wait for it to reset."
            "subscription_sharing_usage_unavailable" -> "ChatGPT plan usage is not available for this account right now."
            else -> {
                val tail = e?.optString("message").orEmpty()
                "Request failed" + (if (code.isNotEmpty()) " ($code)" else "") + (if (tail.isNotEmpty()) ": $tail" else "")
            }
        }
    }

    private fun message(body: String): String = try {
        val j = JSONObject(body); val e = j.opt("error")
        if (e is JSONObject) e.optString("message").ifEmpty { e.optString("code") } else (e as? String ?: body.take(160))
    } catch (x: Exception) { body.take(160) }
}
