package com.unofficial.chatgptvr.ui

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.content.res.ColorStateList
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.EditText
import android.widget.TextView
import android.text.InputType
import android.view.inputmethod.EditorInfo
import kotlin.math.min
import kotlin.math.sin

/** Original dark palette (black canvas, soft gray surfaces, blue accent). Not OpenAI artwork. */
object C {
    const val BG = 0xFF000000.toInt()
    const val SURFACE = 0xFF2F2F2F.toInt()
    const val SURFACE_DARK = 0xFF1C1C1C.toInt()
    const val TEXT = 0xFFFFFFFF.toInt()
    const val MUTED = 0xFF9B9B9B.toInt()
    const val ACCENT = 0xFF3D5AFE.toInt()
    const val LINK = 0xFF7DA2FF.toInt()
    const val DANGER = 0xFFFF6B6B.toInt()
    const val DIVIDER = 0xFF3F3F3F.toInt()
}

/** Layout helpers sized for VR controller pointing: big targets (>= 64dp), hover feedback, scalable text. */
class Ui(val ctx: Context, var textScale: Float) {
    private val density = ctx.resources.displayMetrics.density
    fun dp(v: Int) = (v * density).toInt()
    fun sp(v: Float) = v * textScale

    fun rounded(color: Int, radiusDp: Int = 28, strokeColor: Int = 0, strokeDp: Int = 0) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radiusDp).toFloat(); if (strokeDp > 0) setStroke(dp(strokeDp), strokeColor)
    }

    /** Adds a press ripple and a hover highlight, which is how the Quest pointer shows what you are aiming at. */
    fun touchable(v: View, bg: GradientDrawable, onClick: () -> Unit) {
        v.background = RippleDrawable(ColorStateList.valueOf(0x44FFFFFF), bg, null)
        v.isClickable = true
        v.setOnClickListener { onClick() }
        v.setOnHoverListener { view, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_HOVER_ENTER -> view.alpha = 0.82f
                MotionEvent.ACTION_HOVER_EXIT -> view.alpha = 1f
            }
            false
        }
    }

    fun text(t: String, size: Float = 18f, color: Int = C.TEXT, bold: Boolean = false, gravity: Int = Gravity.START) = TextView(ctx).apply {
        text = t; textSize = sp(size); setTextColor(color); this.gravity = gravity
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
    }

    fun pill(label: String, bg: Int, fg: Int = C.TEXT, size: Float = 18f, strokeColor: Int = 0, onClick: () -> Unit) = TextView(ctx).apply {
        text = label; textSize = sp(size); setTextColor(fg); gravity = Gravity.CENTER
        minHeight = dp(64); minimumHeight = dp(64); setPadding(dp(24), dp(10), dp(24), dp(10))
        touchable(this, rounded(bg, 32, strokeColor, if (strokeColor != 0) 2 else 0), onClick)
    }

    fun iconButton(icon: Icon, bg: Int = C.SURFACE, sizeDp: Int = 64, tint: Int = C.TEXT, onClick: () -> Unit) = IconView(ctx, icon, tint).apply {
        minimumWidth = dp(sizeDp); minimumHeight = dp(sizeDp)
        touchable(this, rounded(bg, sizeDp / 2), onClick)
    }

    fun input(hint: String, sizeSp: Float = 19f) = EditText(ctx).apply {
        this.hint = hint; setHintTextColor(C.MUTED); setTextColor(C.TEXT); textSize = sp(sizeSp); background = null
        inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        maxLines = 5; minHeight = dp(56); setPadding(dp(8), dp(8), dp(8), dp(8)); imeOptions = EditorInfo.IME_ACTION_SEND
    }
}

enum class Icon { MENU, PLUS, MIC, WAVE, CLOSE, BACK, EDIT, SEARCH, CHEVRON, DOWN, COPY, SPARK, CHAT, STOP, SEND }

/** Vector icons drawn in code so no logos or screenshots are shipped. */
class IconView(ctx: Context, var icon: Icon, var tint: Int = Color.WHITE) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
    override fun onMeasure(w: Int, h: Int) {
        val mw = if (MeasureSpec.getMode(w) == MeasureSpec.EXACTLY) MeasureSpec.getSize(w) else minimumWidth
        val mh = if (MeasureSpec.getMode(h) == MeasureSpec.EXACTLY) MeasureSpec.getSize(h) else minimumHeight
        setMeasuredDimension(mw, mh)
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat(); val x = w / 2; val y = h / 2; val u = min(w, h)
        p.color = tint; p.strokeWidth = u * 0.065f; p.style = Paint.Style.STROKE
        when (icon) {
            Icon.MENU -> { c.drawLine(x - u * .22f, y - u * .07f, x + u * .22f, y - u * .07f, p); c.drawLine(x - u * .22f, y + u * .07f, x + u * .06f, y + u * .07f, p) }
            Icon.PLUS -> { c.drawLine(x - u * .2f, y, x + u * .2f, y, p); c.drawLine(x, y - u * .2f, x, y + u * .2f, p) }
            Icon.MIC -> {
                c.drawRoundRect(RectF(x - u * .07f, y - u * .24f, x + u * .07f, y + u * .04f), u * .07f, u * .07f, p)
                c.drawArc(RectF(x - u * .15f, y - u * .13f, x + u * .15f, y + u * .15f), 0f, 180f, false, p)
                c.drawLine(x, y + u * .15f, x, y + u * .24f, p)
            }
            Icon.WAVE -> {
                val hs = floatArrayOf(.08f, .2f, .3f, .2f, .08f)
                for (i in 0 until 5) { val bx = x + (i - 2) * u * .11f; c.drawLine(bx, y - u * hs[i], bx, y + u * hs[i], p) }
            }
            Icon.CLOSE -> { c.drawLine(x - u * .15f, y - u * .15f, x + u * .15f, y + u * .15f, p); c.drawLine(x + u * .15f, y - u * .15f, x - u * .15f, y + u * .15f, p) }
            Icon.BACK -> { c.drawLine(x - u * .2f, y, x + u * .2f, y, p); c.drawLine(x - u * .2f, y, x - u * .04f, y - u * .16f, p); c.drawLine(x - u * .2f, y, x - u * .04f, y + u * .16f, p) }
            Icon.EDIT -> {
                c.drawRoundRect(RectF(x - u * .2f, y - u * .16f, x + u * .12f, y + u * .2f), u * .06f, u * .06f, p)
                c.drawLine(x - u * .02f, y + u * .04f, x + u * .2f, y - u * .2f, p)
            }
            Icon.SEARCH -> { c.drawCircle(x - u * .04f, y - u * .04f, u * .14f, p); c.drawLine(x + u * .07f, y + u * .07f, x + u * .2f, y + u * .2f, p) }
            Icon.CHEVRON -> { c.drawLine(x - u * .06f, y - u * .14f, x + u * .08f, y, p); c.drawLine(x + u * .08f, y, x - u * .06f, y + u * .14f, p) }
            Icon.DOWN -> { c.drawLine(x, y - u * .18f, x, y + u * .18f, p); c.drawLine(x, y + u * .18f, x - u * .12f, y + u * .06f, p); c.drawLine(x, y + u * .18f, x + u * .12f, y + u * .06f, p) }
            Icon.COPY -> {
                c.drawRoundRect(RectF(x - u * .06f, y - u * .2f, x + u * .2f, y + u * .06f), u * .04f, u * .04f, p)
                c.drawRoundRect(RectF(x - u * .2f, y - u * .06f, x + u * .06f, y + u * .2f), u * .04f, u * .04f, p)
            }
            Icon.SPARK -> {
                val r = u * .2f
                c.drawLine(x, y - r, x, y + r, p); c.drawLine(x - r, y, x + r, y, p)
                c.drawLine(x - r * .55f, y - r * .55f, x + r * .55f, y + r * .55f, p); c.drawLine(x + r * .55f, y - r * .55f, x - r * .55f, y + r * .55f, p)
            }
            Icon.CHAT -> {
                c.drawRoundRect(RectF(x - u * .2f, y - u * .17f, x + u * .2f, y + u * .1f), u * .1f, u * .1f, p)
                c.drawLine(x - u * .08f, y + u * .1f, x - u * .14f, y + u * .2f, p); c.drawLine(x - u * .14f, y + u * .2f, x + u * .02f, y + u * .1f, p)
            }
            Icon.SEND -> { c.drawLine(x, y + u * .18f, x, y - u * .18f, p); c.drawLine(x, y - u * .18f, x - u * .12f, y - u * .06f, p); c.drawLine(x, y - u * .18f, x + u * .12f, y - u * .06f, p) }
            Icon.STOP -> { p.style = Paint.Style.FILL; c.drawRoundRect(RectF(x - u * .12f, y - u * .12f, x + u * .12f, y + u * .12f), u * .04f, u * .04f, p) }
        }
    }
}

/** Voice Mode orb. state: 0 paused, 1 listening, 2 thinking, 3 speaking. */
class OrbView(ctx: Context) : View(ctx) {
    var state = 0
        set(v) { field = v; invalidate() }
    private var phase = 0f
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 1800; repeatCount = ValueAnimator.INFINITE
        addUpdateListener { phase = it.animatedValue as Float; invalidate() }
    }
    override fun onAttachedToWindow() { super.onAttachedToWindow(); anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f; val cy = height / 2f; val base = min(width, height) * 0.26f
        val a = (phase * 2 * Math.PI).toFloat()
        val scale = when (state) { 1 -> 1f + 0.07f * sin(a); 3 -> 1f + 0.14f * sin(2 * a); else -> 1f }
        val core = when (state) { 1 -> 0xFF4C7DFF.toInt(); 2 -> 0xFF8A8FA8.toInt(); 3 -> 0xFF9CC2FF.toInt(); else -> 0xFF555555.toInt() }
        val r = base * scale
        paint.style = Paint.Style.FILL
        paint.shader = RadialGradient(cx, cy, r * 1.9f, (core and 0x00FFFFFF) or 0x66000000, Color.TRANSPARENT, Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, r * 1.9f, paint)
        paint.shader = RadialGradient(cx - r * .25f, cy - r * .3f, r * 1.2f, Color.WHITE, core, Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, r, paint)
        paint.shader = null
        if (state == 2) {
            paint.style = Paint.Style.STROKE; paint.strokeWidth = base * .08f; paint.color = Color.WHITE; paint.strokeCap = Paint.Cap.ROUND
            c.drawArc(RectF(cx - r * 1.35f, cy - r * 1.35f, cx + r * 1.35f, cy + r * 1.35f), phase * 360f, 90f, false, paint)
        }
    }
}
