package com.unofficial.chatgptvr

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.SpeechRecognizer
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.unofficial.chatgptvr.ai.ModelInfo
import com.unofficial.chatgptvr.ai.Msg
import com.unofficial.chatgptvr.ai.OpenAiApi
import com.unofficial.chatgptvr.auth.OpenAiAuth
import com.unofficial.chatgptvr.auth.SecretStore
import com.unofficial.chatgptvr.ui.C
import com.unofficial.chatgptvr.ui.Icon
import com.unofficial.chatgptvr.ui.IconView
import com.unofficial.chatgptvr.ui.OrbView
import com.unofficial.chatgptvr.ui.Ui
import com.unofficial.chatgptvr.voice.Voice

/**
 * Unofficial ChatGPT VR. Independent app, not made, endorsed or sponsored by OpenAI.
 * One 2D panel window (Companion Mode) with Chat Mode and Voice Mode; every control is a real view.
 */
class MainActivity : Activity() {
    private lateinit var ui: Ui
    private lateinit var secrets: SecretStore
    private lateinit var auth: OpenAiAuth
    private lateinit var api: OpenAiApi
    private lateinit var voice: Voice
    private lateinit var store: ChatStore
    private lateinit var prefs: SharedPreferences
    private val handler = Handler(Looper.getMainLooper())
    private val hideToast = Runnable { toastView.visibility = View.GONE }

    private var convs = mutableListOf<Conversation>()
    private var cur = Conversation()
    private var models: List<ModelInfo> = emptyList()
    private var model: ModelInfo? = null
    private var busy = false
    private var dictating = false
    private var voiceActive = false
    private var muted = false
    private var vState = 0 // 0 paused, 1 listening, 2 thinking, 3 speaking
    private var failStreak = 0

    private lateinit var root: FrameLayout
    private lateinit var chatScreen: View
    private lateinit var signInScreen: View
    private lateinit var settingsScreen: FrameLayout
    private lateinit var settingsBody: LinearLayout
    private lateinit var drawer: FrameLayout
    private lateinit var drawerList: LinearLayout
    private lateinit var drawerSearch: EditText
    private lateinit var voiceScreen: FrameLayout
    private lateinit var sheetLayer: FrameLayout
    private lateinit var toastView: TextView
    private lateinit var msgs: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var emptyState: View
    private lateinit var jumpBtn: View
    private lateinit var titleView: TextView
    private lateinit var input: EditText
    private lateinit var actionBtn: IconView
    private lateinit var signInStatus: TextView
    private lateinit var orb: OrbView
    private lateinit var voiceStatus: TextView
    private lateinit var voiceText: TextView
    private lateinit var pauseBtn: TextView

    private val MATCH = -1
    private val WRAP = -2
    private fun dp(v: Int) = ui.dp(v)
    private fun lin(w: Int, h: Int, weight: Float = 0f) = LinearLayout.LayoutParams(w, h, weight)

    // ------------------------------------------------------------ lifecycle
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("ucv_prefs", MODE_PRIVATE)
        ui = Ui(this, prefs.getFloat("scale", 1.1f))
        secrets = SecretStore(this); auth = OpenAiAuth(secrets); api = OpenAiApi(auth); store = ChatStore(secrets)
        voice = Voice(this, { onHeard(it) }, { toast(it) }, { onSpeechFail(it) })
        voice.initTts()
        convs = store.load()
        cur = convs.firstOrNull { it.id == prefs.getString("cur", "") } ?: Conversation()

        buildUi()
        refreshAll()
        if (auth.isSignedIn()) loadModels()
        if (prefs.getBoolean("reopen_settings", false)) { prefs.edit().remove("reopen_settings").apply(); openSettings() }
    }

    override fun onPause() { persist(); super.onPause() }
    override fun onDestroy() { voice.shutdown(); super.onDestroy() }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            sheetLayer.visibility == View.VISIBLE -> closeSheet()
            drawer.visibility == View.VISIBLE -> closeDrawer()
            settingsScreen.visibility == View.VISIBLE -> settingsScreen.visibility = View.GONE
            voiceActive -> exitVoiceMode()
            else -> @Suppress("DEPRECATION") super.onBackPressed()
        }
    }

    private fun persist() { prefs.edit().putString("cur", cur.id).apply(); if (convs.isNotEmpty()) store.save(convs) }

    // ------------------------------------------------------------ UI construction
    private fun buildUi() {
        root = FrameLayout(this).apply { setBackgroundColor(C.BG) }
        chatScreen = buildChatScreen()
        signInScreen = buildSignInScreen()
        settingsScreen = buildSettingsScreen()
        drawer = buildDrawer()
        voiceScreen = buildVoiceScreen()
        sheetLayer = FrameLayout(this).apply { visibility = View.GONE }
        toastView = ui.text("", 16f).apply {
            background = ui.rounded(0xEE2F2F2F.toInt(), 24); setPadding(dp(20), dp(12), dp(20), dp(12)); visibility = View.GONE
        }
        for (v in listOf(chatScreen, signInScreen, settingsScreen, drawer, voiceScreen, sheetLayer)) root.addView(v, FrameLayout.LayoutParams(MATCH, MATCH))
        root.addView(toastView, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = dp(150); leftMargin = dp(24); rightMargin = dp(24) })
        setContentView(root)
    }

    private fun buildChatScreen(): View {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(12), dp(16), dp(10)) }

        val top = FrameLayout(this)
        top.addView(ui.iconButton(Icon.MENU) { openDrawer() }, FrameLayout.LayoutParams(dp(64), dp(64), Gravity.START or Gravity.CENTER_VERTICAL))
        titleView = ui.text("Unofficial ChatGPT VR", 19f, C.TEXT, true, Gravity.CENTER).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END }
        top.addView(titleView, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.CENTER).apply { leftMargin = dp(84); rightMargin = dp(84) })
        top.addView(ui.iconButton(Icon.EDIT) { newChat() }, FrameLayout.LayoutParams(dp(64), dp(64), Gravity.END or Gravity.CENTER_VERTICAL))
        col.addView(top, lin(MATCH, dp(72)))

        val area = FrameLayout(this)
        msgs = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 0, 0, dp(16)) }
        scroll = ScrollView(this).apply { addView(msgs); isVerticalScrollBarEnabled = false }
        area.addView(scroll, FrameLayout.LayoutParams(MATCH, MATCH))
        emptyState = buildEmptyState()
        area.addView(emptyState, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM))
        jumpBtn = ui.iconButton(Icon.DOWN, C.SURFACE, 56) { scrollDown() }.apply { visibility = View.GONE }
        area.addView(jumpBtn, FrameLayout.LayoutParams(dp(56), dp(56), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = dp(8) })
        scroll.viewTreeObserver.addOnScrollChangedListener {
            val child = scroll.getChildAt(0)
            val atBottom = child == null || child.bottom - (scroll.height + scroll.scrollY) < dp(48)
            jumpBtn.visibility = if (atBottom || msgs.childCount == 0) View.GONE else View.VISIBLE
        }
        col.addView(area, lin(MATCH, 0, 1f))

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            background = ui.rounded(C.SURFACE, 40); setPadding(dp(8), dp(6), dp(8), dp(6))
        }
        bar.addView(ui.iconButton(Icon.PLUS, C.SURFACE_DARK, 56) { quickActions() })
        input = ui.input("Ask anything").apply {
            setOnEditorActionListener { _, id, _ -> if (id == EditorInfo.IME_ACTION_SEND) { sendFromInput(); true } else false }
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) { updateActionIcon() }
            })
        }
        bar.addView(input, lin(0, WRAP, 1f).apply { leftMargin = dp(6); rightMargin = dp(6) })
        bar.addView(ui.iconButton(Icon.MIC, C.SURFACE, 56) { dictate() })
        actionBtn = ui.iconButton(Icon.WAVE, C.ACCENT, 56) { if (input.text.isNullOrBlank()) enterVoiceMode() else sendFromInput() }
        bar.addView(actionBtn, lin(dp(56), dp(56)).apply { leftMargin = dp(6) })
        col.addView(bar, lin(MATCH, WRAP).apply { topMargin = dp(8) })
        col.addView(ui.text("Unofficial app. Not affiliated with or endorsed by OpenAI. Replies can be wrong.", 12f, C.MUTED, false, Gravity.CENTER)
            .apply { setPadding(0, dp(8), 0, 0) })
        return col
    }

    private fun buildEmptyState(): View {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(8), dp(8), dp(8)) }
        col.addView(ui.text("What can I help with?", 26f, C.TEXT, true, Gravity.CENTER).apply { setPadding(0, 0, 0, dp(18)) })
        fun row(icon: Icon, label: String, starter: String) {
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(14), dp(8), dp(14), dp(8)) }
            r.addView(IconView(this, icon).apply { minimumWidth = dp(48); minimumHeight = dp(48) }, lin(dp(48), dp(48)))
            r.addView(ui.text(label, 20f).apply { setPadding(dp(14), 0, 0, 0) })
            ui.touchable(r, ui.rounded(0x00000000, 20)) { input.setText(starter); input.setSelection(starter.length); focusInput() }
            col.addView(r, lin(MATCH, dp(72)))
        }
        row(Icon.SPARK, "Learn something", "Teach me about ")
        row(Icon.EDIT, "Write or edit", "Help me write ")
        row(Icon.CHAT, "Brainstorm ideas", "Brainstorm ideas for ")
        return col
    }

    private fun buildSignInScreen(): View {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(32), dp(32), dp(32), dp(32)) }
        col.addView(IconView(this, Icon.CHAT).apply { minimumWidth = dp(96); minimumHeight = dp(96); background = ui.rounded(C.SURFACE, 48) }, lin(dp(96), dp(96)))
        col.addView(ui.text("Sign in", 30f, C.TEXT, true, Gravity.CENTER).apply { setPadding(0, dp(20), 0, dp(8)) })
        col.addView(ui.text("Chat with ChatGPT using your own account. Your browser opens OpenAI's sign-in page. " +
            "This app never sees your password and you never paste an API key.", 17f, C.MUTED, false, Gravity.CENTER))
        col.addView(ui.pill("Continue with ChatGPT", C.BG, C.TEXT, 19f, C.MUTED) { startSignIn() }, lin(MATCH, WRAP).apply { topMargin = dp(26) })
        signInStatus = ui.text("", 15f, C.LINK, false, Gravity.CENTER).apply { setPadding(0, dp(14), 0, 0) }
        col.addView(signInStatus)
        col.addView(ui.text("Unofficial app. Not made, endorsed or sponsored by OpenAI. Uses your ChatGPT plan allowance (Plus or Pro).",
            13f, C.MUTED, false, Gravity.CENTER).apply { setPadding(0, dp(28), 0, 0) })
        return FrameLayout(this).apply { setBackgroundColor(C.BG); addView(col, FrameLayout.LayoutParams(MATCH, MATCH)) }
    }

    private fun buildSettingsScreen(): FrameLayout {
        val f = FrameLayout(this).apply { setBackgroundColor(C.BG); visibility = View.GONE; isClickable = true }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(12), dp(16), dp(12)) }
        val top = FrameLayout(this)
        top.addView(ui.iconButton(Icon.BACK) { settingsScreen.visibility = View.GONE }, FrameLayout.LayoutParams(dp(64), dp(64), Gravity.START or Gravity.CENTER_VERTICAL))
        top.addView(ui.text("Settings", 22f, C.TEXT, true, Gravity.CENTER), FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER))
        col.addView(top, lin(MATCH, dp(72)))
        settingsBody = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(8), 0, dp(24)) }
        col.addView(ScrollView(this).apply { addView(settingsBody); isVerticalScrollBarEnabled = false }, lin(MATCH, 0, 1f))
        f.addView(col, FrameLayout.LayoutParams(MATCH, MATCH))
        return f
    }

    private fun buildDrawer(): FrameLayout {
        val f = FrameLayout(this).apply { visibility = View.GONE }
        f.addView(View(this).apply { setBackgroundColor(0x99000000.toInt()); setOnClickListener { closeDrawer() } }, FrameLayout.LayoutParams(MATCH, MATCH))
        val width = minOf((resources.displayMetrics.widthPixels * 0.84f).toInt(), dp(560))
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(0xFF1B1B1B.toInt()); setPadding(dp(18), dp(18), dp(18), dp(16)); isClickable = true }
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(ui.text("Chats", 26f, C.TEXT, true), lin(0, WRAP, 1f))
        head.addView(ui.iconButton(Icon.SEARCH) { drawerSearch.visibility = if (drawerSearch.visibility == View.VISIBLE) View.GONE else View.VISIBLE; if (drawerSearch.visibility == View.GONE) drawerSearch.setText("") else drawerSearch.requestFocus() })
        panel.addView(head, lin(MATCH, dp(72)))
        drawerSearch = ui.input("Search chats").apply {
            visibility = View.GONE; background = ui.rounded(C.SURFACE, 28); setPadding(dp(16), dp(10), dp(16), dp(10))
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) { populateDrawer() }
            })
        }
        panel.addView(drawerSearch, lin(MATCH, WRAP).apply { bottomMargin = dp(8) })
        panel.addView(drawerRow(Icon.EDIT, "New chat") { closeDrawer(); newChat() }, lin(MATCH, dp(68)))
        panel.addView(drawerRow(Icon.CHEVRON, "Settings") { closeDrawer(); openSettings() }, lin(MATCH, dp(68)))
        panel.addView(ui.text("Recent", 15f, C.MUTED, true).apply { setPadding(dp(8), dp(14), 0, dp(6)) })
        drawerList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        panel.addView(ScrollView(this).apply { addView(drawerList); isVerticalScrollBarEnabled = false }, lin(MATCH, 0, 1f))
        val me = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(10), 0, 0) }
        me.addView(ui.text("?", 20f, Color.BLACK, true, Gravity.CENTER).apply { tag = "avatar"; background = ui.rounded(0xFFF59E0B.toInt(), 28) }, lin(dp(56), dp(56)))
        me.addView(View(this), lin(0, 1, 1f))
        me.addView(ui.pill("New chat", C.ACCENT, C.TEXT, 19f) { closeDrawer(); newChat() })
        panel.addView(me, lin(MATCH, WRAP))
        f.addView(panel, FrameLayout.LayoutParams(width, MATCH, Gravity.START))
        return f
    }

    private fun drawerRow(icon: Icon, label: String, onClick: () -> Unit): View {
        val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(10), 0, dp(10), 0) }
        r.addView(IconView(this, icon).apply { minimumWidth = dp(44); minimumHeight = dp(44) }, lin(dp(44), dp(44)))
        r.addView(ui.text(label, 20f).apply { setPadding(dp(12), 0, 0, 0) })
        ui.touchable(r, ui.rounded(0x00000000, 20), onClick)
        return r
    }

    private fun buildVoiceScreen(): FrameLayout {
        val f = FrameLayout(this).apply { setBackgroundColor(C.BG); visibility = View.GONE; isClickable = true }
        f.addView(ui.text("Voice Mode", 20f, C.MUTED, true), FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.START).apply { topMargin = dp(30); leftMargin = dp(24) })
        f.addView(ui.iconButton(Icon.CLOSE) { exitVoiceMode() }, FrameLayout.LayoutParams(dp(64), dp(64), Gravity.TOP or Gravity.END).apply { topMargin = dp(16); rightMargin = dp(16) })
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(28), dp(90), dp(28), dp(130)) }
        orb = OrbView(this).apply { setOnClickListener { onOrbTap() } }
        col.addView(orb, lin(dp(340), dp(340)))
        voiceStatus = ui.text("", 24f, C.TEXT, true, Gravity.CENTER)
        col.addView(voiceStatus, lin(MATCH, WRAP))
        voiceText = ui.text("", 17f, C.MUTED, false, Gravity.CENTER).apply { maxLines = 6; ellipsize = TextUtils.TruncateAt.END; setPadding(0, dp(12), 0, 0) }
        col.addView(voiceText, lin(MATCH, WRAP))
        f.addView(col, FrameLayout.LayoutParams(MATCH, MATCH))
        val bottom = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        pauseBtn = ui.pill("Pause", C.SURFACE) { togglePause() }
        bottom.addView(pauseBtn, lin(dp(190), WRAP).apply { rightMargin = dp(12) })
        bottom.addView(ui.pill("End", 0xFFB3261E.toInt()) { exitVoiceMode() }, lin(dp(190), WRAP))
        f.addView(bottom, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM).apply { bottomMargin = dp(28) })
        return f
    }

    // ------------------------------------------------------------ screens / state
    private fun refreshAll() {
        val signed = auth.isSignedIn()
        signInScreen.visibility = if (signed) View.GONE else View.VISIBLE
        chatScreen.visibility = if (signed) View.VISIBLE else View.GONE
        if (signed) renderConversation()
    }

    private fun renderConversation() {
        msgs.removeAllViews()
        cur.messages.forEach { addMessageView(it.role, it.text, true) }
        emptyState.visibility = if (cur.messages.isEmpty()) View.VISIBLE else View.GONE
        titleView.text = if (cur.messages.isEmpty()) "Unofficial ChatGPT VR" else cur.title
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
        updateActionIcon()
    }

    private fun updateActionIcon() { actionBtn.icon = if (input.text.isNullOrBlank()) Icon.WAVE else Icon.SEND; actionBtn.invalidate() }

    /** User = right-aligned rounded bubble. Assistant = plain left text with a Copy action. Returns (text view, actions row). */
    private fun addMessageView(role: String, text: String, done: Boolean): Pair<TextView, View?> {
        if (role == "user") {
            val wrap = LinearLayout(this).apply { gravity = Gravity.END }
            val tv = ui.text(text, 19f).apply { background = ui.rounded(C.SURFACE, 26); setPadding(dp(20), dp(14), dp(20), dp(14)); setTextIsSelectable(true) }
            wrap.addView(tv, lin(WRAP, WRAP).apply { leftMargin = dp(56) })
            msgs.addView(wrap, lin(MATCH, WRAP).apply { topMargin = dp(16) })
            return Pair(tv, null)
        }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val tv = ui.text(text, 19f).apply { setLineSpacing(0f, 1.18f); setTextIsSelectable(true) }
        col.addView(tv, lin(MATCH, WRAP))
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; visibility = if (done) View.VISIBLE else View.GONE }
        actions.addView(ui.pill("Copy", C.SURFACE_DARK, C.MUTED, 14f) { copy(tv.text.toString()) }.apply { minHeight = dp(52); minimumHeight = dp(52) })
        col.addView(actions, lin(WRAP, WRAP).apply { topMargin = dp(6) })
        msgs.addView(col, lin(MATCH, WRAP).apply { topMargin = dp(16) })
        return Pair(tv, actions)
    }

    private fun scrollDown() { scroll.post { scroll.fullScroll(View.FOCUS_DOWN) } }

    private fun focusInput() {
        input.requestFocus()
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(input, InputMethodManager.SHOW_IMPLICIT)
    }

    private fun toast(msg: String) {
        toastView.text = msg; toastView.visibility = View.VISIBLE
        handler.removeCallbacks(hideToast)
        handler.postDelayed(hideToast, 3200)
    }

    private fun copy(text: String) {
        (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("reply", text)); toast("Copied")
    }

    private fun newChat() {
        if (busy) { toast("Wait for the reply to finish."); return }
        cur = Conversation(); renderConversation()
    }

    private fun openConversation(c: Conversation) {
        if (busy) { toast("Wait for the reply to finish."); return }
        cur = c; closeDrawer(); renderConversation()
    }

    // ------------------------------------------------------------ chat
    private fun sendFromInput() { val t = input.text.toString(); if (t.isBlank()) return; input.setText(""); sendMessage(t) }

    private fun sendMessage(raw: String) {
        val text = raw.trim(); if (text.isEmpty()) return
        if (busy) { toast("Still replying..."); return }
        val m = model ?: run { toast("Models are still loading. Try again in a moment."); if (voiceActive) setVState(0); return }
        if (cur.messages.isEmpty()) { cur.title = text.take(42); if (cur !in convs) convs.add(0, cur) }
        val conv = cur
        conv.messages.add(Msg("user", text)); conv.updated = System.currentTimeMillis()
        emptyState.visibility = View.GONE; titleView.text = conv.title
        addMessageView("user", text, true)
        val (tv, actions) = addMessageView("assistant", "", false)
        scrollDown(); busy = true
        val snapshot = conv.messages.toList()
        val custom = prefs.getString("custom", null)
        Thread {
            try {
                val full = api.stream(m.slug, snapshot, custom) { d -> runOnUiThread { tv.append(d); scrollDown() } }
                runOnUiThread {
                    busy = false; conv.messages.add(Msg("assistant", full)); conv.updated = System.currentTimeMillis()
                    persist(); actions?.visibility = View.VISIBLE; onReplyDone(full)
                }
            } catch (e: Exception) {
                runOnUiThread {
                    busy = false; conv.messages.removeAt(conv.messages.size - 1)
                    tv.text = "Something went wrong: ${e.message}"; tv.setTextColor(C.DANGER)
                    if (voiceActive) { setVState(0); voiceText.text = e.message ?: "" }
                }
            }
        }.start()
    }

    private fun onReplyDone(full: String) {
        if (voiceActive) {
            voiceText.text = full
            if (voice.ttsReady) { setVState(3); voice.speak(full) { if (voiceActive && !muted) listenNow() } }
            else handler.postDelayed({ if (voiceActive && !muted) listenNow() }, 1500)
        } else if (prefs.getBoolean("read", false) && voice.ttsReady) voice.speak(full) {}
    }

    // ------------------------------------------------------------ voice
    private fun dictate() {
        if (voice.listening) { voice.stopListening(); dictating = false; return }
        dictating = true
        if (!voice.listen()) dictating = false
    }

    private fun enterVoiceMode() {
        if (busy) return
        if (model == null) { toast("Models are still loading."); return }
        if (!voice.sttAvailable) {
            sheet("Voice Mode is not available", "This headset does not provide speech recognition to apps, so hands-free Voice Mode can't run. " +
                "Chat Mode works fully. You can also try the microphone key on the system keyboard to dictate.")
            return
        }
        voiceActive = true; muted = false; failStreak = 0; voiceText.text = ""
        voiceScreen.visibility = View.VISIBLE
        listenNow()
    }

    private fun exitVoiceMode() {
        voiceActive = false; voice.stopListening(); voice.stopSpeaking()
        voiceScreen.visibility = View.GONE; renderConversation()
    }

    private fun listenNow() {
        if (!voiceActive || muted) return
        setVState(1)
        if (!voice.listen()) setVState(0)
    }

    private fun setVState(s: Int) {
        vState = s; orb.state = s
        voiceStatus.text = when (s) { 1 -> "Listening..."; 2 -> "Thinking..."; 3 -> "Speaking..."; else -> if (muted) "Paused" else "Tap the orb to talk" }
        pauseBtn.text = if (muted) "Resume" else "Pause"
    }

    private fun onOrbTap() {
        when (vState) {
            3 -> { voice.stopSpeaking(); muted = false; listenNow() }
            0 -> { muted = false; failStreak = 0; listenNow() }
            else -> {}
        }
    }

    private fun togglePause() {
        if (!muted) { muted = true; voice.stopListening(); voice.stopSpeaking(); setVState(0) } else { muted = false; failStreak = 0; listenNow() }
    }

    private fun onHeard(text: String) {
        if (voiceActive) { failStreak = 0; setVState(2); voiceText.text = "You: $text"; sendMessage(text) }
        else if (dictating) {
            dictating = false
            input.setText((input.text.toString() + " " + text).trim()); input.setSelection(input.text.length)
        }
    }

    private fun onSpeechFail(code: Int) {
        if (voiceActive && !muted) {
            if (code == SpeechRecognizer.ERROR_NO_MATCH || code == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) {
                failStreak++
                if (failStreak < 3) handler.postDelayed({ if (voiceActive && !muted && vState == 1) listenNow() }, 500) else setVState(0)
            } else { setVState(0); toast("Speech recognition error ($code).") }
        } else if (dictating) { dictating = false; toast("Didn't catch that.") }
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        if (code != Voice.REQ_MIC) return
        if (results.firstOrNull() == PackageManager.PERMISSION_GRANTED) { toast("Microphone allowed."); if (voiceActive) listenNow() }
        else { toast("Microphone denied. Typing still works."); if (voiceActive) exitVoiceMode() }
    }

    // ------------------------------------------------------------ sign-in
    private fun startSignIn() {
        signInStatus.text = "Starting..."
        auth.signIn(this, { s -> runOnUiThread { signInStatus.text = s } }) { result ->
            runOnUiThread {
                result.onSuccess { signInStatus.text = ""; refreshAll(); loadModels() }
                    .onFailure { signInStatus.text = "Sign-in failed: ${it.message}" }
            }
        }
    }

    private fun loadModels() {
        Thread {
            try {
                val list = api.listModels()
                runOnUiThread { models = list; model = list.firstOrNull(); if (model == null) toast("No models available for this account.") }
            } catch (e: Exception) { runOnUiThread { toast("Could not load models: ${e.message}") } }
        }.start()
    }

    // ------------------------------------------------------------ drawer
    private fun openDrawer() {
        populateDrawer(); drawer.visibility = View.VISIBLE
        (drawer.findViewWithTag<TextView>("avatar"))?.text = (auth.credentials()?.email?.firstOrNull() ?: '?').uppercase()
    }
    private fun closeDrawer() { drawer.visibility = View.GONE }

    private fun populateDrawer() {
        drawerList.removeAllViews()
        val q = drawerSearch.text.toString().trim().lowercase()
        val list = convs.filter { it.messages.isNotEmpty() && (q.isEmpty() || it.title.lowercase().contains(q)) }.sortedByDescending { it.updated }
        if (list.isEmpty()) drawerList.addView(ui.text(if (q.isEmpty()) "No chats yet." else "No matches.", 17f, C.MUTED).apply { setPadding(dp(10), dp(10), 0, 0) })
        for (c in list) {
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(14), 0, dp(6), 0) }
            r.addView(ui.text(c.title, 19f, if (c === cur) C.TEXT else 0xFFD0D0D0.toInt()).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END }, lin(0, WRAP, 1f))
            r.addView(ui.iconButton(Icon.CLOSE, 0x00000000, 52, C.MUTED) { confirmDelete(c) })
            ui.touchable(r, ui.rounded(if (c === cur) 0xFF2A2A2A.toInt() else 0x00000000, 20)) { openConversation(c) }
            drawerList.addView(r, lin(MATCH, dp(68)))
        }
    }

    private fun confirmDelete(c: Conversation) {
        sheet("Delete this chat?", "\"${c.title}\" will be removed from this headset.", listOf("Delete" to {
            convs.remove(c); if (c === cur) cur = Conversation(); persist(); renderConversation(); populateDrawer()
        }))
    }

    // ------------------------------------------------------------ settings
    private fun openSettings() { populateSettings(); settingsScreen.visibility = View.VISIBLE }

    private fun card(rows: List<View>): View {
        val c = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = ui.rounded(C.SURFACE, 28) }
        rows.forEachIndexed { i, r ->
            if (i > 0) c.addView(View(this).apply { setBackgroundColor(C.DIVIDER) }, lin(MATCH, 1).apply { leftMargin = dp(20) })
            c.addView(r, lin(MATCH, WRAP))
        }
        return c.also { settingsBody.addView(it, lin(MATCH, WRAP).apply { topMargin = dp(16) }) }
    }

    private fun row(title: String, value: String? = null, danger: Boolean = false, onClick: (() -> Unit)? = null): View {
        val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; minimumHeight = dp(76); setPadding(dp(22), dp(10), dp(18), dp(10)) }
        r.addView(ui.text(title, 20f, if (danger) C.DANGER else C.TEXT), lin(0, WRAP, 1f))
        if (value != null) r.addView(ui.text(value, 17f, C.MUTED).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END; maxWidth = dp(260) })
        if (onClick != null) { r.addView(IconView(this, Icon.CHEVRON, C.MUTED).apply { minimumWidth = dp(34); minimumHeight = dp(34) }, lin(dp(34), dp(34))); ui.touchable(r, ui.rounded(0x00000000, 28), onClick) }
        return r
    }

    private fun toggleRow(title: String, key: String): View {
        val on = prefs.getBoolean(key, false)
        val r = row(title) as LinearLayout
        r.addView(ui.pill(if (on) "On" else "Off", if (on) C.ACCENT else C.SURFACE_DARK, C.TEXT, 16f) {
            prefs.edit().putBoolean(key, !on).apply(); populateSettings()
        }.apply { minHeight = dp(52); minimumHeight = dp(52) })
        return r
    }

    private fun scaleRow(): View {
        val r = row("Text size") as LinearLayout
        fun change(delta: Float) {
            val n = (ui.textScale + delta).coerceIn(0.9f, 1.6f)
            prefs.edit().putFloat("scale", n).putBoolean("reopen_settings", true).apply(); recreate()
        }
        r.addView(ui.iconButton(Icon.CHEVRON, C.SURFACE_DARK, 56) { change(-0.1f) }.apply { rotation = 180f })
        r.addView(ui.text("${(ui.textScale * 100).toInt()}%", 17f, C.MUTED, false, Gravity.CENTER), lin(dp(76), WRAP))
        r.addView(ui.iconButton(Icon.CHEVRON, C.SURFACE_DARK, 56) { change(0.1f) })
        return r
    }

    private fun populateSettings() {
        settingsBody.removeAllViews()
        val c = auth.credentials()
        val custom = prefs.getString("custom", "") ?: ""
        card(listOf(row("Account", c?.email ?: "Not signed in"), row("Sign out", null, true) {
            sheet("Sign out?", "Removes the sign-in tokens from this headset. Your saved chats stay until you delete them.", listOf("Sign out" to {
                auth.signOutLocal(); model = null; models = emptyList(); settingsScreen.visibility = View.GONE; refreshAll()
            }))
        }))
        card(listOf(
            row("Custom instructions", if (custom.isBlank()) "Off" else "On") { editCustom() },
            row("Model", model?.name ?: "Loading...") { chooseModel() }))
        card(listOf(scaleRow(), toggleRow("Read replies aloud", "read")))
        card(listOf(
            row("Companion Mode") { sheet("Companion Mode", COMPANION, listOf("Minimize now" to { moveTaskToBack(true) })) },
            row("Usage and limits") { sheet("Usage and limits", USAGE) },
            row("Diagnostics") { sheet("Diagnostics", diagnostics()) },
            row("Privacy") { sheet("Privacy", PRIVACY) },
            row("About") { sheet("About", ABOUT) }))
        card(listOf(row("Delete all chats", null, true) {
            sheet("Delete all chats?", "This removes every saved chat from this headset.", listOf("Delete all" to { convs.clear(); cur = Conversation(); persist(); renderConversation() }))
        }))
    }

    private fun editCustom() {
        val e = ui.input("e.g. Keep answers short and friendly.").apply {
            setText(prefs.getString("custom", "")); background = ui.rounded(C.SURFACE, 22); setPadding(dp(16), dp(12), dp(16), dp(12)); minLines = 3
        }
        sheet("Custom instructions", "Sent with every message to shape replies.", editor = e, onSave = { prefs.edit().putString("custom", e.text.toString().trim()).apply(); populateSettings() })
    }

    private fun chooseModel() {
        if (models.isEmpty()) { toast("No models loaded yet."); return }
        sheet("Choose a model", null, models.map { m -> m.name to { model = m; populateSettings() } })
    }

    private fun quickActions() {
        sheet("Quick actions", null, listOf(
            "New chat" to { newChat() },
            "Copy last reply" to { cur.messages.lastOrNull { it.role == "assistant" }?.let { copy(it.text) } ?: toast("Nothing to copy yet.") },
            "Settings" to { openSettings() },
            "Minimize window" to { moveTaskToBack(true) }))
    }

    private fun diagnostics(): String {
        val c = auth.credentials()
        return listOf(
            "Device: ${Build.MANUFACTURER} ${Build.MODEL}",
            "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})",
            "Headset feature (head tracking): ${packageManager.hasSystemFeature("android.hardware.vr.headtracking")}",
            "Multi-window mode: $isInMultiWindowMode",
            "Speech recognition available: ${voice.sttAvailable}",
            "Text-to-speech ready: ${voice.ttsReady}",
            "Microphone permission: ${voice.hasMicPermission}",
            "Signed in: ${c != null}" + (c?.let { " (plan scope: ${"chatgpt.tokens.use.direct" in it.scopes})" } ?: ""),
            "Model: ${model?.slug ?: "none"}"
        ).joinToString("\n")
    }

    // ------------------------------------------------------------ bottom sheet
    private fun closeSheet() { sheetLayer.visibility = View.GONE; sheetLayer.removeAllViews() }

    private fun sheet(title: String, body: String? = null, options: List<Pair<String, () -> Any?>> = emptyList(), editor: EditText? = null, onSave: (() -> Unit)? = null) {
        sheetLayer.removeAllViews()
        sheetLayer.addView(View(this).apply { setBackgroundColor(0xAA000000.toInt()); setOnClickListener { closeSheet() } }, FrameLayout.LayoutParams(MATCH, MATCH))
        val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = ui.rounded(0xFF1E1E1E.toInt(), 32); setPadding(dp(22), dp(22), dp(22), dp(22)) }
        card.addView(ui.text(title, 22f, C.TEXT, true))
        if (body != null) card.addView(ui.text(body, 17f, C.MUTED).apply { setPadding(0, dp(10), 0, dp(6)); setLineSpacing(0f, 1.15f) })
        if (editor != null) card.addView(editor, lin(MATCH, WRAP).apply { topMargin = dp(10) })
        for ((label, act) in options) card.addView(ui.pill(label, C.SURFACE) { closeSheet(); act() }, lin(MATCH, WRAP).apply { topMargin = dp(10) })
        if (onSave != null) card.addView(ui.pill("Save", C.ACCENT) { onSave(); closeSheet() }, lin(MATCH, WRAP).apply { topMargin = dp(12) })
        card.addView(ui.pill("Close", 0x00000000, C.MUTED) { closeSheet() }, lin(MATCH, WRAP).apply { topMargin = dp(8) })
        sheetLayer.addView(ScrollView(this).apply { addView(card) }, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM).apply { setMargins(dp(12), dp(12), dp(12), dp(12)) })
        sheetLayer.visibility = View.VISIBLE
    }

    private companion object {
        const val COMPANION = "Horizon OS shows this app as a floating window. Point at the window's bar to move it, " +
            "drag a corner to resize it, and minimize it to the tray above the system menu; reopen it from there.\n\n" +
            "Whether it can stay open beside a particular VR game depends on that game and your Horizon OS version. " +
            "Apps cannot draw their own overlay on top of other VR apps."
        const val USAGE = "Chats use your own ChatGPT plan allowance. You can see and limit what this app may use in your ChatGPT settings. " +
            "If a limit is reached, the app shows the message instead of failing silently."
        const val PRIVACY = "No password, API key or secret is typed into or stored by this app. Sign-in happens on OpenAI's own page in Quest Browser. " +
            "Only the OAuth tokens OpenAI issues are kept, encrypted by an Android Keystore key.\n\n" +
            "Your chats are saved only on this headset (encrypted) and are sent only to OpenAI to get replies. Voice uses the headset's own speech engines."
        const val ABOUT = "Unofficial ChatGPT VR is an independent, free, open-source app. It is not made, endorsed or sponsored by OpenAI. " +
            "ChatGPT is a trademark of its owner. The interface is original artwork; no OpenAI logos or screenshots are included.\n\nVersion 0.2.0"
    }
}
